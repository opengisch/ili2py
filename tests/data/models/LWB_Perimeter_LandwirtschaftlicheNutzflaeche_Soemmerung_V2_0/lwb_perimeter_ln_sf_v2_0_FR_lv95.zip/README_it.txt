Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Perimetro SAU e superfici d’estivazione
Ciclo di aggiornamento:
    Annuale
Stato attuale (ultima pubblicazione):
    27.11.2025 10:07:12
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
