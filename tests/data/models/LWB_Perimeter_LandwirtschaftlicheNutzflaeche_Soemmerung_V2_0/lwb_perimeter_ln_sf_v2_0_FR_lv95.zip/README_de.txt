Detailinformationen Kanton 
---------------------------

Thema:
    Perimeter Landwirtschaftliche Nutzfläche und Sömmerung
Aktualisierungs-Zyklus:
    Jährlich
Zeitstand (letzte Publikation):
    27.11.2025 10:07:12
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
