Informations détaillées du canton 
----------------------------------

Thème:
    Périmètre SAU et surface d’estivage
Cycle de mise à jour:
    annuelle
Date de dernière publication:
    27.11.2025 10:07:12
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
