Detailinformationen Kanton 
---------------------------

Thema:
    Lärmempfindlichkeitsstufen (in Nutzungszonen)
Aktualisierungs-Zyklus:
    Benutzerdefiniert
Zeitstand (letzte Publikation):
    17.10.2026 10:44:18
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
