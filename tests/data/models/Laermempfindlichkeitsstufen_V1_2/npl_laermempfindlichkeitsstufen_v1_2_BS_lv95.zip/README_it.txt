Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Gradi di sensibilità al rumore (in zone d’utilizzazione)
Ciclo di aggiornamento:
    Definita dall’utente
Stato attuale (ultima pubblicazione):
    17.10.2026 10:44:18
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
