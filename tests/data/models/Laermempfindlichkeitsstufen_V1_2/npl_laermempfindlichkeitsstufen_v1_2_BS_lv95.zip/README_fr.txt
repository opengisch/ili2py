Informations détaillées du canton 
----------------------------------

Thème:
    Degré de sensibilité au bruit (dans les zones d’affectation)
Cycle de mise à jour:
    définie par l’utilisateur
Date de dernière publication:
    17.10.2026 10:44:18
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
