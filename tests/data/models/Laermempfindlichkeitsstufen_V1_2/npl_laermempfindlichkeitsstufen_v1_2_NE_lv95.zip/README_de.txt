Detailinformationen Kanton 
---------------------------

Thema:
    Lärmempfindlichkeitsstufen (in Nutzungszonen)
Aktualisierungs-Zyklus:
    Unregelmässig
Zeitstand (letzte Publikation):
    17.12.2025 11:50:20
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
