Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Gradi di sensibilità al rumore (in zone d’utilizzazione)
Ciclo di aggiornamento:
    Irregolare
Stato attuale (ultima pubblicazione):
    17.12.2025 11:50:20
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
