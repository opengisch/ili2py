Informations détaillées du canton 
----------------------------------

Thème:
    Degré de sensibilité au bruit (dans les zones d’affectation)
Cycle de mise à jour:
    irrégulière
Date de dernière publication:
    17.12.2025 11:50:20
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
